package com.example.lks

import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

fun login(email: String, password: String, callback: (String) -> Unit) {
    thread {
        try {
            val url = URL("http://10.0.2.2:5000/api/auth")
            val conn = url.openConnection() as HttpURLConnection

            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json")
            conn.doOutput = true

            val jsonParams = JSONObject();
            jsonParams.put("email", email)
            jsonParams.put("password", password)

            val os = conn.outputStream
            os.write(jsonParams.toString().toByteArray())
            os.flush()
            os.close()

            val responseCode = conn.responseCode
            val reader = if (responseCode in 200..299) {
                BufferedReader(InputStreamReader(conn.inputStream))
            } else {
                BufferedReader(InputStreamReader(conn.errorStream))
            }

            val response = reader.use { it.readText() }
            reader.close()
            conn.disconnect()

            callback(response)
        } catch (e: Exception) {
            callback("Error: ${e.message}")
        }
    }
}